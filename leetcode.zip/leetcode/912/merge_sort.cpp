#include<iostream>
#include<vector>

using namespace std;

class Solution
{
    void merge( )
    {

    }
    void merge_sort( )
    {

    }
public:
    vector<int> sortArray(vector<int> &nums)
    {
        return nums;
    }
};

int main( )
{
    return 0;
}